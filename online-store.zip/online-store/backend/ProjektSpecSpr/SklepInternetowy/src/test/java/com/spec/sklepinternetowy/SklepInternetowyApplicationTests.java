package com.spec.sklepinternetowy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SklepInternetowyApplicationTests {

    @Test
    void contextLoads() {
    }

}
