package com.spec.sklepinternetowy.registration;

public class LoginEmailCheckResponse {
    private boolean loginExists;
    private boolean emailExists;

    public boolean isLoginExists() {
        return loginExists;
    }

    public void setLoginExists(boolean loginExists) {
        this.loginExists = loginExists;
    }

    public boolean isEmailExists() {
        return emailExists;
    }

    public void setEmailExists(boolean emailExists) {
        this.emailExists = emailExists;
    }

    public LoginEmailCheckResponse() {
    }

    public LoginEmailCheckResponse(boolean loginExists, boolean emailExists) {
        this.loginExists = loginExists;
        this.emailExists = emailExists;
    }
}
