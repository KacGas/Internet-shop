package com.spec.sklepinternetowy.items;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ItemService {

    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    //testy
    @Transactional(readOnly = true)
    public boolean categoryExistsByName(String categoryName) {
        return categoryRepository.existsByName(categoryName);
    }

    // Metoda do dodawania nowego przedmiotu
    @Transactional
    public ResponseEntity<?> addItem(Item item) {
        String itemName = item.getName();
        if (itemRepository.existsByName(itemName)) {
            String errorMessage = "Item with name '" + itemName + "' already exists.";
            System.err.println(errorMessage); // Wyświetl błąd w konsoli
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        } else {
            Item newItem = itemRepository.save(item);
            return ResponseEntity.ok(newItem);
        }
    }

    // Metoda do pobierania wszystkich przedmiotów
    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    // Metoda do pobierania przedmiotu o określonym id
    public Item getItemById(Long id) {
        Optional<Item> optionalItem = itemRepository.findById(id);
        return optionalItem.orElse(null);
    }

    // Metoda do aktualizacji przedmiotu
    @Transactional
    public ResponseEntity<?> updateItem(Long id, Item itemDetails) {
        String itemName = itemDetails.getName();

        // Sprawdź, czy przedmiot o danej nazwie już istnieje (z pominięciem aktualizowanego przedmiotu)
        if (itemRepository.existsByNameAndIdNot(itemName, id)) {
            // Wyświetl błąd w konsoli
            String errorMessage = "Item with name '" + itemName + "' already exists.";
            System.err.println(errorMessage);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        } else {
            Optional<Item> optionalItem = itemRepository.findById(id);
            if (optionalItem.isPresent()) {
                Item existingItem = optionalItem.get();
                existingItem.setName(itemName);
                // Aktualizuj pozostałe pola przedmiotu...
                Item updatedItem = itemRepository.save(existingItem);
                return ResponseEntity.ok(updatedItem);
            } else {
                return ResponseEntity.notFound().build();
            }
        }
    }

    // Metoda do usuwania przedmiotu
    @Transactional
    public boolean deleteItem(Long id) {
        if (itemRepository.existsById(id)) {
            itemRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }


    //KATEGORIA
    @Transactional
    public ResponseEntity<?> addCategory(Category category) {
        String categoryName = category.getName();
        if (categoryRepository.existsByName(categoryName)) {
            String errorMessage = "Category with name '" + categoryName + "' already exists.";
            System.err.println(errorMessage); // Wyświetl błąd w konsoli
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        } else {
            Category newCategory = categoryRepository.save(category);
            return ResponseEntity.ok(newCategory);
        }
    }
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }
    public Category getCategoryById(Long id) {
        Optional<Category> optionalCategory = categoryRepository.findById(id);
        return optionalCategory.orElse(null);
    }
    public Category updateCategory(Long id, Category categoryDetails) {
        String categoryName = categoryDetails.getName();

        // Sprawdź, czy kategoria o danej nazwie już istnieje (z pominięciem aktualizowanej kategorii)
        if (categoryRepository.existsByNameAndIdNot(categoryName, id)) {
            // Wyświetl błąd w konsoli
            String errorMessage = "Category with name '" + categoryName + "' already exists.";
            System.err.println(errorMessage);
            return null;
        } else {
            Optional<Category> optionalCategory = categoryRepository.findById(id);
            if (optionalCategory.isPresent()) {
                Category existingCategory = optionalCategory.get();
                existingCategory.setName(categoryName);
                return categoryRepository.save(existingCategory);
            } else {
                return null;
            }
        }
    }
    public boolean deleteCategory(Long id) {
        if (categoryRepository.existsById(id)) {
            categoryRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }
}