package com.spec.sklepinternetowy.order_information;

import com.spec.sklepinternetowy.cart.CartItem;
import com.spec.sklepinternetowy.cart.CartItemRepository;
import com.spec.sklepinternetowy.cart.CartService;
import com.spec.sklepinternetowy.delivery_method.DeliveryMethod;
import com.spec.sklepinternetowy.delivery_method.DeliveryMethodRepository;
import com.spec.sklepinternetowy.delivery_method.DeliveryMethodService;
import com.spec.sklepinternetowy.order_status.OrderStatus;
import com.spec.sklepinternetowy.order_status.OrderStatusRepository;
import com.spec.sklepinternetowy.order_status.OrderStatusService;
import com.spec.sklepinternetowy.payment_method.PaymentMethod;
import com.spec.sklepinternetowy.payment_method.PaymentMethodRepository;
import com.spec.sklepinternetowy.payment_method.PaymentMethodService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderInformationService {

    private final OrderInformationRepository orderInformationRepository;
    private final OrderStatusService orderStatusService;
    private final PaymentMethodService paymentMethodService;
    private final DeliveryMethodService deliveryMethodService;

    @Autowired
    private OrderStatusRepository orderStatusRepository;

    @Autowired
    private PaymentMethodRepository paymentMethodRepository;

    @Autowired
    private DeliveryMethodRepository deliveryMethodRepository;

    private final CartService cartService;

    @Autowired
    public OrderInformationService(OrderInformationRepository orderInformationRepository,
                                   OrderStatusService orderStatusService,
                                   PaymentMethodService paymentMethodService,
                                   DeliveryMethodService deliveryMethodService,
                                   CartService cartService) {
        this.orderInformationRepository = orderInformationRepository;
        this.orderStatusService = orderStatusService;
        this.paymentMethodService = paymentMethodService;
        this.deliveryMethodService = deliveryMethodService;
        this.cartService = cartService;
    }

    public List<OrderInformation> getAllOrders() {
        return orderInformationRepository.findAll();
    }

    public OrderInformation getOrderById(Long id) {
        return orderInformationRepository.findById(id).orElse(null);
    }

    @Transactional
    public OrderInformation createOrder(Long orderStatusId, Long paymentMethodId, Long deliveryMethodId, Long cartItemId) {
        OrderStatus orderStatus = orderStatusService.getOrderStatusById(orderStatusId);
        PaymentMethod paymentMethod = paymentMethodService.getPaymentMethodById(paymentMethodId);
        DeliveryMethod deliveryMethod = deliveryMethodService.getDeliveryMethodById(deliveryMethodId);
        CartItem cartItem = cartService.getCartItemById(cartItemId); // Używamy poprawionej metody

        if (orderStatus != null && paymentMethod != null && deliveryMethod != null && cartItem != null) {
            OrderInformation orderInformation = new OrderInformation(orderStatus, paymentMethod, deliveryMethod, cartItem);
            return orderInformationRepository.save(orderInformation);
        } else {
            // Handle null scenarios or throw exceptions as per application logic
            return null;
        }
    }

    public List<OrderStatus> getAllOrderStatuses() {
        return orderStatusRepository.findAll();
    }

    public List<PaymentMethod> getAllPaymentMethods() {
        return paymentMethodRepository.findAll();
    }

    public List<DeliveryMethod> getAllDeliveryMethods() {
        return deliveryMethodRepository.findAll();
    }

//    private CartItem getCartItemById(Long cartItemId) {
//        // Implement logic to retrieve CartItem by ID from repository or service
//        // Example:
//        return cartItemRepository.findById(cartItemId).orElse(null);
//    }
}

