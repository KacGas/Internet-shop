package com.spec.sklepinternetowy.registration;

import com.spec.sklepinternetowy.auth.AuthenticationRequest;
import com.spec.sklepinternetowy.auth.AuthenticationResponse;
import com.spec.sklepinternetowy.cart.CartItem;
import com.spec.sklepinternetowy.cart.CartService;
import com.spec.sklepinternetowy.config.JwtService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Optional;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;

    public User findByEmail(String email) {
        return userRepository.findByEmail(email).orElseThrow(() -> new IllegalArgumentException("User not found"));
    }

//    LOGOWANIE???
public AuthenticationResponse login(AuthenticationRequest request) {
    // Autentykacja użytkownika
    Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                    request.getEmail(),
                    request.getPassword()
            )
    );

    // Pobranie zautoryzowanego użytkownika
    UserDetails userDetails = (UserDetails) authentication.getPrincipal();

    // Generowanie tokena JWT
    String jwtToken = jwtService.generateToken(userDetails);

    // Tworzenie obiektu AuthenticationResponse
    AuthenticationResponse response = new AuthenticationResponse();
    response.setToken(jwtToken);

    return response;
}


// WCZYTYWANIE ZALOGOWANEGO UZYTKOWNIKA ???


    public AuthenticationResponse authenticate(AuthenticationRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();

        User user = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        String jwtToken = jwtService.generateToken(user);

        AuthenticationResponse response = new AuthenticationResponse();
        response.setToken(jwtToken);

        return response;
    }

    @Transactional
    public ResponseEntity<?> registerUser(UserRegistrationRequest request) {
        ResponseEntity<?> validationResponse = validateUserRegistrationRequest(request);
        if (validationResponse != null) {
            return validationResponse;
        }
        User user = mapUserRequestToUser(request);
        userRepository.save(user);
        String jwtToken = jwtService.generateToken(user); //dodane
        AuthenticationResponse authenticationResponse = new AuthenticationResponse(jwtToken); //dodane
        authenticationResponse.setToken(jwtToken); //dodane
        return ResponseEntity.ok(authenticationResponse); //zmienione (w srodku string tylko)
    }
    public ResponseEntity<?> validateUserRegistrationRequest(UserRegistrationRequest request) {
        if (userRepository.existsByLogin(request.getLogin())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Błąd walidacji: Podany login już istnieje.");
        }

        if (userRepository.existsByEmail(request.getEmail())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Błąd walidacji: Podany email już istnieje.");
        }

        return null;
    }

    private User mapUserRequestToUser(UserRegistrationRequest request) {
        User user = new User();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setLogin(request.getLogin());
        user.setEmail(request.getEmail());
        user.setPhoneNumber(request.getPhoneNumber());
        user.setPassword(passwordEncoder.encode(request.getPassword())); //dodac kiedys zabezpieczenia hasla
        user.setRepeatedPassword(request.getRepeatedPassword()); //dodac kiedys zabezpieczenia hasla
        user.setRole(Role.USER);
        return user;
    }

    public User generateSampleUser() {
        User user = new User();
        user.setFirstName("Kacperqqqq");
        user.setLastName("Gasowski");
        user.setLogin("asdasd");
        user.setEmail("sdsd");
        user.setPhoneNumber("asdasd");
        user.setPassword("123");
        user.setRepeatedPassword("123");
        user.setRole(Role.USER);
        String jwtToken = jwtService.generateToken(user);
        return user;
    }

    public boolean existsByLogin(String login) {
        return userRepository.existsByLogin(login);
    }
    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return userRepository.findByEmail(username)
        .orElseThrow(() -> {
            return new UsernameNotFoundException("User not found " + username);
        });
    }


    //TEST UPDATE
    public ResponseEntity<?> updateUserProfile(UserUpdateRequest request) {
        // Pobierz użytkownika z bazy danych na podstawie jego identyfikatora lub innego unikalnego atrybutu
        // (np. adresu e-mail) i zaktualizuj jego dane

        User user = userRepository.findByLogin(request.getLogin())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Zaktualizuj dane użytkownika
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setPhoneNumber(request.getPhoneNumber());
        user.setEmail(request.getEmail());

        // Zapisz zmiany w bazie danych
        userRepository.save(user);

        return ResponseEntity.ok("Dane użytkownika zostały pomyślnie zaktualizowane.");
    }

    public ResponseEntity<?> validateUserUpdateRequest(UserUpdateRequest request, String currentUserEmail) {
        String newEmail = request.getEmail();
        if (!newEmail.equals(currentUserEmail) && userRepository.existsByEmail(newEmail)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Błąd walidacji: Podany adres e-mail już istnieje.");
        }
        return null;
    }

    private UserDetails getCurrentUserDetails() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            Object principal = authentication.getPrincipal();
            if (principal instanceof UserDetails) {
                return (UserDetails) principal;
            }
        }
        return null;
    }

    public User getCurrentUser() {
        UserDetails userDetails = getCurrentUserDetails();
        if (userDetails != null) {
            return userRepository.findByEmail(userDetails.getUsername())
                    .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        }
        return null;
    }

}
