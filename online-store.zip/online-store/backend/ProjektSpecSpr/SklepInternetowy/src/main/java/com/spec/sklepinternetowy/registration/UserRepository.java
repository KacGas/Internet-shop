package com.spec.sklepinternetowy.registration;

import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    boolean existsByLogin(String login);
    boolean existsByEmail(String email);

    boolean existsByEmailAndEmailNot(String email, String currentUserEmail);

    Optional<User> findByEmail(String email);

    Optional<User> findByLogin(String login);


}
