package com.spec.sklepinternetowy.cart;

import com.spec.sklepinternetowy.items.Item;
import com.spec.sklepinternetowy.registration.User;
import com.spec.sklepinternetowy.registration.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @Autowired
    private UserService userService;

    @PostMapping("/add")
    public ResponseEntity<?> addItemToCart(@RequestParam Long itemId, @RequestParam int quantity) {
        User user = userService.getCurrentUser();
        if (user != null) {
            CartItem cartItem = cartService.addItemToCart(user.getId(), itemId, quantity);
            if (cartItem != null) {
                return ResponseEntity.ok(cartItem);
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    @GetMapping("/items")
    public ResponseEntity<List<CartItem>> getCartItems() {
        User user = userService.getCurrentUser();
        if (user != null) {
            List<CartItem> cartItems = cartService.getCartItemsByUserId(user.getId());
            return ResponseEntity.ok(cartItems);
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    @DeleteMapping("/remove/{id}")
    public ResponseEntity<?> removeItemFromCart(@PathVariable Long id) {
        User user = userService.getCurrentUser();
        if (user != null) {
            cartService.removeItemFromCart(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    // Dodaj dodatkowe endpointy do aktualizacji ilości, czyszczenia koszyka itp.
}
