package com.spec.sklepinternetowy.delivery_method;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/delivery-methods")
public class DeliveryMethodController {

    private final DeliveryMethodService deliveryMethodService;

    @Autowired
    public DeliveryMethodController(DeliveryMethodService deliveryMethodService) {
        this.deliveryMethodService = deliveryMethodService;
    }

    @GetMapping
    public List<DeliveryMethod> getAllDeliveryMethods() {
        return deliveryMethodService.getAllDeliveryMethods();
    }

    @GetMapping("/{id}")
    public DeliveryMethod getDeliveryMethodById(@PathVariable Long id) {
        return deliveryMethodService.getDeliveryMethodById(id);
    }

    @PostMapping
    public DeliveryMethod createDeliveryMethod(@RequestBody DeliveryMethod deliveryMethod) {
        return deliveryMethodService.saveDeliveryMethod(deliveryMethod);
    }

    @PutMapping("/{id}")
    public DeliveryMethod updateDeliveryMethod(@PathVariable Long id, @RequestBody DeliveryMethod deliveryMethod) {
        deliveryMethod.setId(id);
        return deliveryMethodService.saveDeliveryMethod(deliveryMethod);
    }

    @DeleteMapping("/{id}")
    public void deleteDeliveryMethod(@PathVariable Long id) {
        deliveryMethodService.deleteDeliveryMethod(id);
    }
}
