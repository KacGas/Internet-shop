package com.spec.sklepinternetowy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SklepInternetowyApplication {

    public static void main(String[] args) {
        SpringApplication.run(SklepInternetowyApplication.class, args);
    }


}
