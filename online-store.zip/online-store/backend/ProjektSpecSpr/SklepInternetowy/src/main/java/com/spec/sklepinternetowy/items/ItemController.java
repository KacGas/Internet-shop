package com.spec.sklepinternetowy.items;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/items")
public class ItemController {

    @Autowired
    private ItemService itemService;

    @Autowired
    private CategoryRepository categoryRepository;

    // Endpoint do dodawania nowego przedmiotu
    @PostMapping("/add")
    public ResponseEntity<ResponseEntity<?>> addItem(@RequestBody Item item) {
        if (item.getCategory() == null) {
            // Poinformuj użytkownika o konieczności wybrania kategorii
            return ResponseEntity.badRequest().body(null);
        }

        Category category = categoryRepository.findById(item.getCategory().getId())
                .orElseThrow(() -> new RuntimeException("Category not found"));
        item.setCategory(category);
        ResponseEntity<?> newItem = itemService.addItem(item);
        return ResponseEntity.ok(newItem);
    }

    // Endpoint do pobierania wszystkich przedmiotów
    @GetMapping("/all")
    public ResponseEntity<List<Item>> getAllItems() {
        List<Item> items = itemService.getAllItems();
        return ResponseEntity.ok(items);
    }

    // Endpoint do pobierania przedmiotu o określonym id
    @GetMapping("/{id}")
    public ResponseEntity<Item> getItemById(@PathVariable Long id) {
        Item item = itemService.getItemById(id);
        if (item != null) {
            return ResponseEntity.ok(item);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Endpoint do edycji przedmiotu
    @PutMapping("/edit/{id}")
    public ResponseEntity<ResponseEntity<?>> updateItem(@PathVariable Long id, @RequestBody Item itemDetails) {
        ResponseEntity<?> updatedItem = itemService.updateItem(id, itemDetails);
        if (updatedItem != null) {
            return ResponseEntity.ok(updatedItem);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Endpoint do usuwania przedmiotu
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteItem(@PathVariable Long id) {
        boolean deleted = itemService.deleteItem(id);
        if (deleted) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/add-category")
    public ResponseEntity<ResponseEntity<?>> addCategory(@RequestBody Category category) {
        ResponseEntity<?> newCategory = itemService.addCategory(category);
        return ResponseEntity.ok(newCategory);
    }

    @PutMapping("/edit-category/{id}")
    public ResponseEntity<Category> updateCategory(@PathVariable Long id, @RequestBody Category categoryDetails) {
        Category updatedCategory = itemService.updateCategory(id, categoryDetails);
        if (updatedCategory != null) {
            return ResponseEntity.ok(updatedCategory);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Endpoint do usuwania przedmiotu
    @DeleteMapping("/delete-category/{id}")
    public ResponseEntity<?> deleteCategory(@PathVariable Long id) {
        boolean deleted = itemService.deleteCategory(id);
        if (deleted) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/all-category")
    public ResponseEntity<List<Category>> getAllCategories() {
        List<Category> categories = itemService.getAllCategories();
        return ResponseEntity.ok(categories);
    }

    // Endpoint do pobierania przedmiotu o określonym id
    @GetMapping("/all/{id}")
    public ResponseEntity<Category> getCategoryById(@PathVariable Long id) {
        Category category = itemService.getCategoryById(id);
        if (category != null) {
            return ResponseEntity.ok(category);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}