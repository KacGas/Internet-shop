package com.spec.sklepinternetowy.cart;

import com.spec.sklepinternetowy.delivery_method.DeliveryMethod;
import com.spec.sklepinternetowy.delivery_method.DeliveryMethodService;
import com.spec.sklepinternetowy.items.Item;
import com.spec.sklepinternetowy.items.ItemRepository;
import com.spec.sklepinternetowy.order_information.OrderInformation;
import com.spec.sklepinternetowy.order_information.OrderInformationRepository;
import com.spec.sklepinternetowy.order_information.OrderInformationService;
import com.spec.sklepinternetowy.order_status.OrderStatus;
import com.spec.sklepinternetowy.order_status.OrderStatusService;
import com.spec.sklepinternetowy.payment_method.PaymentMethod;
import com.spec.sklepinternetowy.payment_method.PaymentMethodService;
import com.spec.sklepinternetowy.registration.User;
import com.spec.sklepinternetowy.registration.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private UserRepository userRepository;

    @Transactional
    public CartItem addItemToCart(Long userId, Long itemId, int quantity) {
        Optional<User> optionalUser = userRepository.findById(userId);
        Optional<Item> optionalItem = itemRepository.findById(itemId);

        if (optionalUser.isPresent() && optionalItem.isPresent()) {
            User user = optionalUser.get();
            Item item = optionalItem.get();

            // Sprawdzamy, czy użytkownik już ma ten element w koszyku
            List<CartItem> cartItems = cartItemRepository.findByUser_Id(userId);
            for (CartItem cartItem : cartItems) {
                if (cartItem.getItem().getId().equals(itemId)) {
                    cartItem.setQuantity(cartItem.getQuantity() + quantity);
                    return cartItemRepository.save(cartItem);
                }
            }

            CartItem cartItem = new CartItem();
            cartItem.setUser(user);
            cartItem.setItem(item);
            cartItem.setQuantity(quantity);
            return cartItemRepository.save(cartItem);
        }
        return null;
    }

    public List<CartItem> getCartItemsByUserId(Long userId) {
        return cartItemRepository.findByUser_Id(userId);
    }

    public CartItem getCartItemById(Long cartItemId) {
        return cartItemRepository.findById(cartItemId).orElse(null);
    }


    @Transactional
    public void removeItemFromCart(Long cartItemId) {
        cartItemRepository.deleteById(cartItemId);
    }

    // Pozostałe metody do obsługi koszyka (aktualizacja ilości, czyszczenie koszyka itp.)
}
