package com.spec.sklepinternetowy.order_status;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/order-statuses")
public class OrderStatusController {

    private final OrderStatusService orderStatusService;

    @Autowired
    public OrderStatusController(OrderStatusService orderStatusService) {
        this.orderStatusService = orderStatusService;
    }

    @GetMapping
    public List<OrderStatus> getAllOrderStatuses() {
        return orderStatusService.getAllOrderStatuses();
    }

    @GetMapping("/{id}")
    public OrderStatus getOrderStatusById(@PathVariable Long id) {
        return orderStatusService.getOrderStatusById(id);
    }

    @PostMapping
    public OrderStatus createOrderStatus(@RequestBody OrderStatus orderStatus) {
        return orderStatusService.saveOrderStatus(orderStatus);
    }

    @PutMapping("/{id}")
    public OrderStatus updateOrderStatus(@PathVariable Long id, @RequestBody OrderStatus orderStatus) {
        orderStatus.setId(id);
        return orderStatusService.saveOrderStatus(orderStatus);
    }

    @DeleteMapping("/{id}")
    public void deleteOrderStatus(@PathVariable Long id) {
        orderStatusService.deleteOrderStatus(id);
    }
}
