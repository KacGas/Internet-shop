package com.spec.sklepinternetowy.order_information;

import com.spec.sklepinternetowy.delivery_method.DeliveryMethod;
import com.spec.sklepinternetowy.delivery_method.DeliveryMethodRepository;
import com.spec.sklepinternetowy.order_status.OrderStatus;
import com.spec.sklepinternetowy.order_status.OrderStatusRepository;
import com.spec.sklepinternetowy.payment_method.PaymentMethod;
import com.spec.sklepinternetowy.payment_method.PaymentMethodRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderInformationController {

    private final OrderInformationService orderInformationService;

    @Autowired
    public OrderInformationController(OrderInformationService orderInformationService) {
        this.orderInformationService = orderInformationService;
    }

    @GetMapping
    public List<OrderInformation> getAllOrders() {
        return orderInformationService.getAllOrders();
    }

    @GetMapping("/{id}")
    public OrderInformation getOrderById(@PathVariable Long id) {
        return orderInformationService.getOrderById(id);
    }

    @PostMapping("/create") // Endpoint dla tworzenia nowego zamówienia
    public ResponseEntity<?> createOrder(
            @RequestParam Long orderStatusId,
            @RequestParam Long paymentMethodId,
            @RequestParam Long deliveryMethodId,
            @RequestParam Long cartItemId) {

        try {
            // Tworzymy zamówienie przy użyciu OrderInformationService
            OrderInformation createdOrder = orderInformationService.createOrder(orderStatusId, paymentMethodId, deliveryMethodId, cartItemId);
            return ResponseEntity.ok(createdOrder);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/statuses")
    public List<OrderStatus> getAllOrderStatuses() {
        return orderInformationService.getAllOrderStatuses();
    }

    @GetMapping("/payment-methods")
    public List<PaymentMethod> getAllPaymentMethods() {
        return orderInformationService.getAllPaymentMethods();
    }

    @GetMapping("/delivery-methods")
    public List<DeliveryMethod> getAllDeliveryMethods() {
        return orderInformationService.getAllDeliveryMethods();
    }

//    @PostMapping
//    public OrderInformation createOrder(@RequestBody OrderInformation order) {
//        return orderInformationService.saveOrder(order);
//    }

//    @GetMapping("/statuses")
//    public List<OrderStatus> getAllOrderStatuses() {
//        return orderInformationService.getAllOrderStatuses();
//    }
//
//    @GetMapping("/payment-methods")
//    public List<PaymentMethod> getAllPaymentMethods() {
//        return orderInformationService.getAllPaymentMethods();
//    }
//
//    @GetMapping("/delivery-methods")
//    public List<DeliveryMethod> getAllDeliveryMethods() {
//        return orderInformationService.getAllDeliveryMethods();
//    }
}
