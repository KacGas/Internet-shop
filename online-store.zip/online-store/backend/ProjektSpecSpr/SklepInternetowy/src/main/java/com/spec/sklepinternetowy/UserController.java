package com.spec.sklepinternetowy;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @GetMapping("/profile")
    public UserProfile getUserProfile() {

        UserProfile userProfile = new UserProfile();

        userProfile.setFirstName("Kacperas");
        userProfile.setLastName("Gasowski");
        userProfile.setDateOfBirth(LocalDate.parse("2000-11-09"));

        return userProfile;
    }
}
