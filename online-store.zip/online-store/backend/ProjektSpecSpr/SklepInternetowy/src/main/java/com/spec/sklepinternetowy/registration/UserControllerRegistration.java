package com.spec.sklepinternetowy.registration;

import com.spec.sklepinternetowy.auth.AuthenticationRequest;
import com.spec.sklepinternetowy.auth.AuthenticationResponse;
import com.spec.sklepinternetowy.config.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/user")
@CrossOrigin
public class UserControllerRegistration {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserRepository userRepository;



    // Endpoint dla logowania ???
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody AuthenticationRequest request) {
        AuthenticationResponse response = userService.login(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/authenticate")
    public ResponseEntity<AuthenticationResponse> authenticate(
            @RequestBody AuthenticationRequest request
    ){
        return ResponseEntity.ok(userService.authenticate(request));
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody UserRegistrationRequest request) {
        ResponseEntity<?> validationResponse = userService.validateUserRegistrationRequest(request);
        if (validationResponse != null) {
            return validationResponse;
        }

        ResponseEntity<?> response = userService.registerUser(request);
        if (response.getStatusCode() == HttpStatus.OK) {
            // Jeśli rejestracja zakończona sukcesem, generujemy token JWT i wyświetlamy go
            String jwtToken = jwtService.generateToken(userService.loadUserByUsername(request.getEmail())); //tu ???
            String successMessage = "Rejestracja zakończona sukcesem! Token JWT: " + jwtToken;
            return ResponseEntity.ok(successMessage);
        } else {
            return response;
        }
    }

    @PostMapping("/check-login-email")
    public ResponseEntity<?> checkLoginEmailExists(@RequestBody LoginEmailCheckRequest request) {
        boolean loginExists = userService.existsByLogin(request.getLogin());
        boolean emailExists = userService.existsByEmail(request.getEmail());

        LoginEmailCheckResponse response = new LoginEmailCheckResponse(loginExists, emailExists);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/register2")
    public User getUserReg() {
        return userService.generateSampleUser();
    }

    @GetMapping("/userdata")
    public ResponseEntity<User> getUserProfile() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userRepository.findByEmail(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        return ResponseEntity.ok(user);
    }

    //TEST UPDATE

    @PutMapping("/update")
    public ResponseEntity<?> updateUserProfile(@RequestBody UserUpdateRequest request) throws UnsupportedEncodingException {
        // Pobierz obiekt Authentication z kontekstu bezpieczeństwa
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        // Pobierz aktualny adres e-mail użytkownika
        String currentUserEmail = authentication.getName();

        ResponseEntity<?> validationResponse = userService.validateUserUpdateRequest(request, currentUserEmail);
        if (validationResponse != null) {
            return validationResponse;
        }

        ResponseEntity<?> response = userService.updateUserProfile(request);
        return ResponseEntity.ok(response);
    }
}