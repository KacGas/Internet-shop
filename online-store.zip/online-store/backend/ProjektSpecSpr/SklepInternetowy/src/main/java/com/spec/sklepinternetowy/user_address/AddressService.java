package com.spec.sklepinternetowy.user_address;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AddressService {

    @Autowired
    private AddressRepository addressRepository;

    public List<Address> getUserAddresses(Long userId) {
        return addressRepository.findByUserId(userId);
    }

    public Address addUserAddress(Address address) {
        return addressRepository.save(address);
    }

    public void deleteUserAddress(Long addressId) {
        addressRepository.deleteById(addressId);
    }

    public void setDefaultUserAddress(Long userId, Long addressId) {
        Address currentDefault = addressRepository.findByUserIdAndIsDefault(userId, true);
        if (currentDefault != null) {
            currentDefault.setDefault(false);
            addressRepository.save(currentDefault);
        }
        Address newDefault = addressRepository.findById(addressId).orElseThrow();
        newDefault.setDefault(true);
        addressRepository.save(newDefault);
    }
}
