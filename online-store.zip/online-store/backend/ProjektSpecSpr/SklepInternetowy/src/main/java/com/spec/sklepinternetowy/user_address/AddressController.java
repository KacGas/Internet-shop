package com.spec.sklepinternetowy.user_address;

import com.spec.sklepinternetowy.registration.User;
import com.spec.sklepinternetowy.registration.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/addresses")
public class AddressController {

    @Autowired
    private AddressService addressService;

    @Autowired
    private UserService userService;

    @GetMapping
    public List<Address> getUserAddresses() {
        User user = getCurrentUser();
        return addressService.getUserAddresses(user.getId());
    }

    @PostMapping
    public Address addUserAddress(@RequestBody Address address) {
        User user = getCurrentUser();
        address.setUser(user);
        return addressService.addUserAddress(address);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUserAddress(@PathVariable Long id) {
        addressService.deleteUserAddress(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/default/{id}")
    public ResponseEntity<Void> setDefaultUserAddress(@PathVariable Long id) {
        User user = getCurrentUser();
        addressService.setDefaultUserAddress(user.getId(), id);
        return ResponseEntity.ok().build();
    }

    private User getCurrentUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserDetails) {
            String email = ((UserDetails) principal).getUsername();
            return userService.findByEmail(email);
        } else {
            throw new IllegalStateException("User not authenticated");
        }
    }
}
