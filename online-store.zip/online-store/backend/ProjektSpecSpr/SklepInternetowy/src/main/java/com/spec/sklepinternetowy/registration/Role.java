package com.spec.sklepinternetowy.registration;

public enum Role {
    USER,
    ADMIN
}
