package com.spec.sklepinternetowy.order_information;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderInformationRepository extends JpaRepository<OrderInformation, Long> {
}
