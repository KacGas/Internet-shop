import {
  first
} from "./chunk-G4CLNUOP.js";
export {
  first
};
//# sourceMappingURL=rxjs_internal_operators_first.js.map
