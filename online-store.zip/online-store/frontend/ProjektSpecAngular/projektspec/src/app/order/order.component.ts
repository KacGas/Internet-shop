import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { OrderService} from "../services/order.service";
import {DeliveryMethod, Order, OrderStatus, PaymentMethod} from "../model/oder";

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  orderStatuses: OrderStatus[] = [];
  paymentMethods: PaymentMethod[] = [];
  deliveryMethods: DeliveryMethod[] = [];
  orders: Order[] = [];

  orderId: number = 0;
  order: Order ={} as Order;
  orderStatusId: number = 0;
  paymentMethodId: number = 0;
  deliveryMethodId: number = 0;
  cartItemId: number = 0;

  constructor(private route: ActivatedRoute, private orderService: OrderService) { }

  ngOnInit(): void {
    this.loadOrders();
    this.loadOrderStatuses();
    this.loadPaymentMethods();
    this.loadDeliveryMethods();
    this.fetchOrder();

    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id !== null && id !== undefined) {
        this.orderId = +id;
        this.fetchOrder();
      } else {
        // Handle the case where 'id' is null or undefined
        console.error('No valid ID found in route parameters.');
      }
    });
  }

  loadOrderStatuses(): void {
    this.orderService.getAllOrderStatuses().subscribe(
      statuses => {
        this.orderStatuses = statuses;
      },
      error => {
        console.error('Error loading order statuses:', error);
      }
    );
  }

  loadPaymentMethods(): void {
    this.orderService.getAllPaymentMethods().subscribe(
      methods => {
        this.paymentMethods = methods;
      },
      error => {
        console.error('Error loading payment methods:', error);
      }
    );
  }

  loadDeliveryMethods(): void {
    this.orderService.getAllDeliveryMethods().subscribe(
      methods => {
        this.deliveryMethods = methods;
      },
      error => {
        console.error('Error loading delivery methods:', error);
      }
    );
  }

  fetchOrder(): void {
    this.orderService.getOrderById(this.orderId).subscribe(
      order => {
        this.order = order;
      },
      error => {
        console.error('Error fetching order:', error);
      }
    );
  }

  loadOrders(): void {
    this.orderService.getAllOrders().subscribe(
      orders => {
        this.orders = orders;
      },
      error => {
        console.error('Error loading orders:', error);
      }
    );
  }

  onSubmit(): void {
    this.orderService.createOrder(this.orderStatusId, this.paymentMethodId, this.deliveryMethodId, this.cartItemId)
      .subscribe(
        createdOrder => {
          console.log('Order created:', createdOrder);
          this.loadOrders(); // Optionally reload orders
          // Optionally reset form or handle success
        },
        error => {
          console.error('Error creating order:', error);
          // Handle error scenario
        }
      );
  }

}
