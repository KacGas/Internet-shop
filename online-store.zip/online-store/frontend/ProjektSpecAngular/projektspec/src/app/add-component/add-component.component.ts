import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Category } from '../model/category';
import { CategoryService } from '../services/category.service';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-add-component',
  templateUrl: './add-component.component.html',
  styleUrls: ['./add-component.component.css']
})
export class AddComponentComponent implements OnInit {

  categoryForm: FormGroup;
  categories: Category[] = [];
  errorMessage: string = '';
  editMode: boolean = false;
  selectedCategory: any;

  @Output() categorySelected: EventEmitter<number> = new EventEmitter<number>();

  constructor(private formBuilder: FormBuilder, private categoryService: CategoryService) {
    this.categoryForm = this.formBuilder.group({
      id: [''],
      name: ['', [Validators.required, this.nameTakenValidator.bind(this)]]
    });
  }

  ngOnInit(): void {
    this.loadCategory();
  }

  loadCategory(): void {
    this.categoryService.getCategory()
      .subscribe(
        categories => {
          this.categories = categories;
        },
        error => {
          console.error('Error loading categories:', error);
        }
      );
  }

  editCategory(category: any): void {
    this.editMode = true;
    this.selectedCategory = category;
    this.categoryForm.patchValue(category);
  }

  deleteCategory(categoryId: number): void {
    this.categoryService.deleteCategory(categoryId)
      .subscribe(
        response => {
          console.log('Category deleted successfully!', response);
          this.loadCategory();
        },
        error => {
          console.error('Error deleting category:', error);
        }
      );
  }

  onSubmit(): void {
    if (this.categoryForm.valid) {
      const newCategory = this.categoryForm.value;
      this.categoryService.addCategory(newCategory)
        .pipe(
          catchError((error) => {
            this.errorMessage = error;
            return throwError(error);
          })
        )
        .subscribe(
          response => {
            console.log('Category added successfully!', response);
            this.loadCategory();
            this.categoryForm.reset();
          },
          error => {
            console.error('Error adding category:', error);
          }
        );
    }
  }

  nameTakenValidator(control: any) {
    if (this.categories.find(category => category.name === control.value)) {
      return { nameTaken: true };
    }
    return null;
  }

  selectCategory(categoryId: number): void {
    this.categorySelected.emit(categoryId);
  }
}
