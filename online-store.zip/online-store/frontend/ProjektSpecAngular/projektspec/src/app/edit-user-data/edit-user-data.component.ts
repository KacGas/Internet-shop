import {Component, HostListener, Inject} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {UserProfileLogin} from "../model/user-profile-login";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {UserService} from "../services/user.service";

@Component({
  selector: 'app-edit-user-data',
  templateUrl: './edit-user-data.component.html',
  styleUrl: './edit-user-data.component.css'
})
export class EditUserDataComponent {

  userDataForm!: FormGroup;

  errorMessages: any = {};

  constructor(
    public dialogRef: MatDialogRef<EditUserDataComponent>,
    @Inject(MAT_DIALOG_DATA) public userData: UserProfileLogin,
    private fb: FormBuilder,
    private userService: UserService
  ) {
    this.createForm();
  }

  createForm(): void {
    this.userDataForm = this.fb.group({
      firstName: [this.userData.firstName, [Validators.required, Validators.pattern(/^[a-zA-Z]+$/)]],
      lastName: [this.userData.lastName, [Validators.required, Validators.pattern(/^[a-zA-Z]+$/)]],
      phoneNumber: [this.userData.phoneNumber, [Validators.pattern(/^\d{9}$/)]],
      email: [this.userData.email, [Validators.required, Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/)]],
      password: [this.userData.password, [Validators.required, Validators.minLength(8)]]
    });
  }

  onSubmit(): void {

    this.errorMessages = {}; // Wyczyść bieżące komunikaty o błędach

    // Sprawdź każde pole formularza pod kątem błędów
    Object.keys(this.userDataForm.controls).forEach(field => {
      const control = this.userDataForm.get(field);
      if (control && control.invalid) {
        const errors = control.errors;
        // Przypisz odpowiednie komunikaty o błędach do właściwych pól w formularzu
        if (errors) {
          this.errorMessages[field] = this.getErrorMessage(field, errors);
        }
      }
    });

    // Jeśli formularz jest poprawny, przejdź do zapisu danych
    if (this.userDataForm.valid) {
      this.userService.updateUserProfile(this.userDataForm.value).subscribe(response => {
        console.log(response); // Tutaj możesz obsłużyć odpowiedź od backendu
        this.dialogRef.close();
      });
    }


    if (this.userDataForm.valid) {
      this.userService.updateUserProfile(this.userDataForm.value).subscribe(response => {
        console.log(response); // Tutaj możesz obsłużyć odpowiedź od backendu
        this.dialogRef.close();
      });
    }
  }

  getErrorMessage(field: string, errors: any): string {
    if (field === 'firstName') {
      if (errors.required) {
        return 'Pole Imię nie może być puste.';
      } else if (errors.pattern) {
        return 'Pole Imię może składać się tylko z liter.';
      }
    } else if (field === 'lastName') {
      if (errors.required) {
        return 'Pole Nazwisko nie może być puste.';
      } else if (errors.pattern) {
        return 'Pole Nazwisko może składać się tylko z liter.';
      }
    } else if (field === 'email') {
      if (errors.required) {
        return 'Pole Email nie może być puste.';
      } else if (errors.email) {
        return 'Nieprawidłowy format adresu email.';
      }
    } else if (field === 'phoneNumber') {
      if (errors.pattern) {
        return 'Pole Telefon musi zawierać 9 cyfr.';
      }
    } else if (field === 'password') {
      if (errors.required) {
        return 'Pole Hasło nie może być puste.';
      } else if (errors.minlength) {
        return 'Hasło musi zawierać przynajmniej 8 znaków.';
      }
    }
    return '';
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  @HostListener('window:click', ['$event'])
  onClick(event: MouseEvent): void {
    if ((event.target as HTMLElement).classList.contains('modal-background')) {
      this.dialogRef.close();
    }
  }
}
