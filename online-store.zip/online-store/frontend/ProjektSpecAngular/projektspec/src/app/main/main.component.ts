import { Component } from '@angular/core';
import {UserProfile} from "../model/user-profile";
import {UserProfileRegistration} from "../model/user-profile-registration";
import {UserService} from "../services/user.service";
import {UserRegistrationService} from "../services/user-registration.service";

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrl: './main.component.css'
})
export class MainComponent {
  userProfile?: UserProfile;

  userProfileRegistration?: UserProfileRegistration;

  constructor(private userService: UserService, private userRegistrationService: UserRegistrationService) {
    userService.getUserProfile().subscribe(userProfile => this.userProfile = userProfile);
    userRegistrationService.getUserProfileRegistration().subscribe(userProfileRegistration => this.userProfileRegistration = userProfileRegistration);
  }
}
