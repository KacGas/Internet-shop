import { Component } from '@angular/core';
import {UserRegistrationService} from "../services/user-registration.service";

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  formData = {
    firstName: '',
    lastName: '',
    login: '',
    email: '',
    phoneNumber: '',
    password: '',
    password2: ''
  };
  errorMessages: any = {};
  registrationSuccess = false; // Flaga informująca o sukcesie rejestracji
  registrationMessage = ''; // Komunikat informujący o statusie rejestracji


  constructor(private userRegistrationService: UserRegistrationService) {
  }

  onSubmit() {
    this.errorMessages = {};

    if (!this.formData.firstName) {
      this.errorMessages.firstName = 'Pole Imię nie może być puste.';
    } else if (!/^[a-zA-Z]+$/.test(this.formData.firstName)) {
      this.errorMessages.firstName = 'Pole Imię może zawierać tylko litery.';
    }

    if (!this.formData.lastName) {
      this.errorMessages.lastName = 'Pole Nazwisko nie może być puste.';
    } else if (!/^[a-zA-Z]+$/.test(this.formData.lastName)) {
      this.errorMessages.lastName = 'Pole Nazwisko może zawierać tylko litery.';
    }

    if (!this.formData.login) {
      this.errorMessages.login = 'Pole Login nie może być puste.';
    }

    if (!this.formData.email) {
      this.errorMessages.email = 'Pole Email nie może być puste.';
    } else if (!this.isValidEmail(this.formData.email)) {
      this.errorMessages.email = 'Nieprawidłowy format adresu email.';
    }

    if (!this.formData.phoneNumber) {
      this.errorMessages.phoneNumber = 'Pole Telefon nie może być puste.';
    } else if (!/^\d{9}$/.test(this.formData.phoneNumber)) {
      this.errorMessages.phoneNumber = 'Pole Telefon musi zawierać 9 cyfr.';
    }

    if (!this.formData.password) {
      this.errorMessages.password = 'Pole Hasło nie może być puste.';
    } else if (this.formData.password.length < 8) {
      this.errorMessages.password = 'Hasło musi zawierać przynajmniej 8 znaków.';
    }

    if (this.formData.password !== this.formData.password2) {
      this.errorMessages.password2 = 'Powtórzone hasło nie zgadza się z hasłem.';
    }

    this.userRegistrationService.checkIfLoginOrEmailExists(this.formData.login, this.formData.email).subscribe(
      (result: any) => {
        if (result.loginExists) {
          this.errorMessages.login = 'Login jest już zajęty.';
        }
        if (result.emailExists) {
          this.errorMessages.email = 'Email jest już zajęty.';
        }

        if (Object.keys(this.errorMessages).length === 0) {
          this.userRegistrationService.registerUser(this.formData).subscribe(
            () => {
              console.log('Rejestracja udana.');
              this.registrationSuccess = true;
              this.registrationMessage = 'Użytkownik został pomyślnie zarejestrowany!';
            },
            (error: string) => {
              console.error('Błąd rejestracji:', error);
              // Tutaj można przekazać błędy do HTML, aby wyświetlić je użytkownikowi
            }
          );
        }
      }
    );
  }

  isValidEmail(email: string): boolean {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  }
}
