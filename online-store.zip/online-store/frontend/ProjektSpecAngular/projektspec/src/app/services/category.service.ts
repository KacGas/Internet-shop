import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse} from "@angular/common/http";
import {Observable, throwError} from "rxjs";
import {catchError} from "rxjs/operators";
import {Category} from "../model/category";

const CATEGORY_ADD: string = 'http://localhost:8080/api/items/add-category';
const CATEGORY_EDIT: string = 'http://localhost:8080/api/items/edit-category';
const CATEGORY_DELETE: string = 'http://localhost:8080/api/items/delete-category';
const CATEGORY_ALL: string = 'http://localhost:8080/api/items/all-category';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  constructor(private http: HttpClient) { }

  addCategory(categoryData: any): Observable<any> {
    return this.http.post<any>(CATEGORY_ADD, categoryData).pipe(
      catchError(this.handleError)
    );
  }

  getCategory(): Observable<Category[]> {
    return this.http.get<Category[]>(CATEGORY_ALL).pipe(
      catchError(this.handleError)
    );
  }

  editCategory(categoryId: number, newCategoryData: any): Observable<any> {
    const editUrl = `${CATEGORY_EDIT}/${categoryId}`;
    return this.http.put<any>(editUrl, newCategoryData).pipe(
      catchError(this.handleError)
    );
  }

  deleteCategory(categoryId: number): Observable<any> {
    const deleteUrl = `${CATEGORY_DELETE}/${categoryId}`;
    return this.http.delete<any>(deleteUrl).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    return throwError('Something bad happened; please try again later.');
  }
}
