import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable, tap} from 'rxjs';
import {Router} from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient, private router: Router) { }


  login(loginData: { email: string, password: string }): Observable<any> {
    return this.http.post<any>('http://localhost:8080/api/user/login', loginData).pipe(
      tap(response => {
        if (response && response.token) {
          localStorage.setItem('authToken', response.token);
          console.log('Token JWT został pomyślnie zapisany w pamięci lokalnej przeglądarki.');
        } else {
          console.error('Nie udało się uzyskać tokenu JWT z serwera.');
        }
      })
    );
  }


  logout() {
    // Usunięcie tokenu JWT z pamięci lokalnej przeglądarki
    localStorage.removeItem('authToken');
    // Tutaj możesz dodać dodatkową logikę, np. przekierowanie użytkownika do strony logowania
    this.router.navigate(['/login']);
  }
}
