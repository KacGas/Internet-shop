import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse} from "@angular/common/http";
import {Observable} from "rxjs/internal/Observable";
import {UserProfileRegistration} from "../model/user-profile-registration";
import {first} from "rxjs/internal/operators/first";
import {catchError, map, throwError} from "rxjs";

const USER_PROFILE_PATH: string = 'http://localhost:8080/api/user/register2'
const USER_REGISTER_PATH: string = 'http://localhost:8080/api/user/register';
const CHECK_LOGIN_EMAIL_PATH: string = 'http://localhost:8080/api/user/check-login-email';

@Injectable({
  providedIn: 'root'
})
export class UserRegistrationService {

  constructor(private http: HttpClient) { }

  checkIfLoginOrEmailExists(login: string, email: string): Observable<any> {
    return this.http.post<any>(CHECK_LOGIN_EMAIL_PATH, { login, email }).pipe(
      catchError((error: HttpErrorResponse) => {
        return throwError(error.error.message || 'Wystąpił błąd podczas sprawdzania dostępności loginu i emaila.');
      })
    );
  }

  getUserProfileRegistration(): Observable<UserProfileRegistration>{
    return this.http.get<UserProfileRegistration>(USER_PROFILE_PATH).pipe(first());
  }

  registerUser(userData: any): Observable<any> {
    return this.http.post<any>(USER_REGISTER_PATH, userData).pipe(
      catchError((error: HttpErrorResponse) => {
        return throwError(error.error.message);
      })
    );
  }

  // registerUser(userData: any): Observable<any> {
  //   return this.http.post<any>(USER_REGISTER_PATH, userData).pipe(
  //     map(response => {
  //       console.log('Response:', response);
  //       return response;
  //     }),
  //     catchError(error => {
  //       console.error('Error:', error);
  //       throw error;
  //     })
  //   );
  // }
}
