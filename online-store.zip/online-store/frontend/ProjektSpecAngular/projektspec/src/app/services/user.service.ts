import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs/internal/Observable";
import { first } from "rxjs/internal/operators/first";
import { UserProfile } from "../model/user-profile";
import {UserProfileLogin} from "../model/user-profile-login";
import {catchError, throwError} from "rxjs";
import {Address} from "../model/address";

const USER_PROFILE_PATH: string = 'http://localhost:8080/api/user/profile';
const USER_PROFILE_LOGIN_PATH: string = 'http://localhost:8080/api/user/userdata';
const USER_PROFILE_UPDATE_PATH: string = 'http://localhost:8080/api/user/update';
const USER_ADDRESSES_PATH: string = 'http://localhost:8080/api/addresses';
const USER_ADD_ADDRESS_PATH: string = 'http://localhost:8080/api/addresses';
const USER_DELETE_ADDRESS_PATH: string = 'http://localhost:8080/api/addresses';
const USER_SET_DEFAULT_ADDRESS_PATH: string = 'http://localhost:8080/api/addresses/default';

@Injectable()
export class UserService {

  constructor(private http: HttpClient) {
    }

  getUserData(): Observable<UserProfileLogin>{
    return this.http.get<UserProfileLogin>(USER_PROFILE_LOGIN_PATH).pipe(
        first()
  );
  }

    getUserProfile(): Observable<UserProfile> {
        return this.http.get<UserProfile>(USER_PROFILE_PATH).pipe(
            first()
        );
    }

  updateUserProfile(userData: UserProfile): Observable<any> {
    return this.http.put(USER_PROFILE_UPDATE_PATH, userData).pipe(
      catchError(error => {
        console.error('Wystąpił błąd podczas aktualizacji danych użytkownika:', error);
        return throwError(error);
      })
    );
  }
  getUserAddresses(): Observable<Address[]> {
    return this.http.get<Address[]>(USER_ADDRESSES_PATH).pipe(
      first()
    );
  }

  addUserAddress(address: Address): Observable<Address> {
    return this.http.post<Address>(USER_ADD_ADDRESS_PATH, address).pipe(
      catchError(error => {
        console.error('Wystąpił błąd podczas dodawania adresu:', error);
        return throwError(error);
      })
    );
  }

  deleteUserAddress(addressId: number): Observable<any> {
    const url = `${USER_DELETE_ADDRESS_PATH}/${addressId}`;
    return this.http.delete(url).pipe(
      catchError(error => {
        console.error('Wystąpił błąd podczas usuwania adresu:', error);
        return throwError(error);
      })
    );
  }
  setDefaultUserAddress(addressId: number): Observable<any> {
    const url = `${USER_SET_DEFAULT_ADDRESS_PATH}/${addressId}`;
    return this.http.put(url, {}).pipe(
      catchError(error => {
        console.error('Wystąpił błąd podczas ustawiania adresu domyślnego:', error);
        return throwError(error);
      })
    );
  }
}
