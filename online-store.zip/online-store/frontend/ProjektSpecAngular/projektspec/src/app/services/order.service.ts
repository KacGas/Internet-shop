import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {DeliveryMethod, Order, OrderStatus, PaymentMethod} from "../model/oder";

const ORDER_GET_ALL: string = 'http://localhost:8080/api/orders';
const ORDER_GET_BY_ID: string = `http://localhost:8080/api/orders/{id}`;
const ORDER_POST: string = 'http://localhost:8080/api/orders/create';
const PAYMENT_METHODS_GET_ALL: string = 'http://localhost:8080/api/orders/payment-methods'; // Example URL
const ORDER_STATUS_GET_ALL: string = 'http://localhost:8080/api/orders/statuses'; // Example URL
const DELIVERY_METHOD_GET_ALL: string = 'http://localhost:8080/api/orders/delivery-methods'; // Example URL

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  constructor(private http: HttpClient) { }

  createOrder(orderStatusId: number, paymentMethodId: number, deliveryMethodId: number, cartItemId: number): Observable<Order> {
    const params = {
      orderStatusId: orderStatusId.toString(),
      paymentMethodId: paymentMethodId.toString(),
      deliveryMethodId: deliveryMethodId.toString(),
      cartItemId: cartItemId.toString()
    };
    return this.http.post<Order>(ORDER_POST, params);
  }

  getAllOrders(): Observable<Order[]> {
    return this.http.get<Order[]>(ORDER_GET_ALL);
  }

  getOrderById(id: number): Observable<Order> {
    const url = `${ORDER_GET_BY_ID.replace('{id}', id.toString())}`;
    return this.http.get<Order>(url);
  }

  getAllPaymentMethods(): Observable<PaymentMethod[]> {
    return this.http.get<PaymentMethod[]>(PAYMENT_METHODS_GET_ALL);
  }

  getAllOrderStatuses(): Observable<OrderStatus[]> {
    return this.http.get<OrderStatus[]>(ORDER_STATUS_GET_ALL);
  }

  getAllDeliveryMethods(): Observable<DeliveryMethod[]> {
    return this.http.get<DeliveryMethod[]>(DELIVERY_METHOD_GET_ALL);
  }
}
