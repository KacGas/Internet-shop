import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Item } from '../model/item';
import {Cart} from "../model/cart";

const ITEM_ADD_TO_CART: string = 'http://localhost:8080/api/cart/add';
const GET_ITEMS: string = 'http://localhost:8080/cart/items';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private http: HttpClient) { }

  // Pobierz przedmioty z serwera
  getItems(): Observable<Cart[]> {
    return this.http.get<Cart[]>(GET_ITEMS);
  }

  // Dodaj przedmiot do koszyka
  // addToCart(itemName: string): Observable<any> {
  //   return this.http.post<any>(`${ITEM_ADD_TO_CART}ByName/${itemName}`, {});
  // }

  // addToCart(itemId: number, quantity: number): Observable<any> {
  //   return this.http.post<any>(ITEM_ADD_TO_CART, { itemId, quantity });
  // }

  // Usuń przedmiot z koszyka
  // removeFromCart(cartItemId: number): Observable<any> {
  //   return this.http.delete<any>(`http://localhost:8080/api/cart/remove/${cartItemId}`);
  // }


}
