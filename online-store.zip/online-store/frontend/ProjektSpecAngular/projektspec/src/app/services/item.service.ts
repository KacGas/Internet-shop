import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Item } from '../model/item';

const ITEM_ADD: string = 'http://localhost:8080/api/items/add';
const ITEM_ALL: string = 'http://localhost:8080/api/items/all';
const ITEM_EDIT: string = 'http://localhost:8080/api/items/edit';
const ITEM_DELETE: string = 'http://localhost:8080/api/items/delete';

@Injectable({
  providedIn: 'root'
})
export class ItemService {
  constructor(private http: HttpClient) { }

  addItem(itemData: any): Observable<any> {
    return this.http.post<any>(ITEM_ADD, itemData).pipe(
      catchError(this.handleError)
    );
  }

  getItems(): Observable<Item[]> {
    return this.http.get<Item[]>(ITEM_ALL).pipe(
      catchError(this.handleError)
    );
  }

  editItem(itemId: number, newItemData: any): Observable<any> {
    const editUrl = `${ITEM_EDIT}/${itemId}`;
    return this.http.put<any>(editUrl, newItemData).pipe(
      catchError(this.handleError)
    );
  }

  deleteItem(itemId: number): Observable<any> {
    const deleteUrl = `${ITEM_DELETE}/${itemId}`;
    return this.http.delete<any>(deleteUrl).pipe(
      catchError(this.handleError)
    );
  }
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    return throwError('Something bad happened; please try again later.');
  }
}
