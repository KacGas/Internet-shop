import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  ValidationErrors,
  Validators
} from '@angular/forms';
import { ItemService } from '../services/item.service';
import { CategoryService } from "../services/category.service";
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import {Category} from "../model/category";

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {
  itemForm: FormGroup;
  items: any[] = [];
  categories: Category[] = [];
  errorMessage: string = '';
  editMode: boolean = false;
  selectedItem: any;

  constructor(private formBuilder: FormBuilder, private itemService: ItemService, private categoryService: CategoryService) {
    this.itemForm = this.formBuilder.group({
      id: [''],
      name: ['', [Validators.required, this.nameTakenValidator.bind(this)]],
      price: ['', Validators.required],
      description: ['', Validators.required],
      category: ['', Validators.required],
      quantity: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadCategories();
    this.loadItems();
  }

  loadCategories(): void {
    this.categoryService.getCategory()
      .subscribe(
        categories => {
          this.categories = categories;
        },
        error => {
          console.error('Error loading categories:', error);
        }
      );
  }

  getCategoryName(category: any): string {
    if (!category) {
      return 'Unknown';
    }
    return category.name || 'Unknown';
  }

  loadItems(): void {
    this.itemService.getItems()
      .subscribe(
        items => {
          this.items = items;
        },
        error => {
          console.error('Error loading items:', error);
        }
      );
  }

  editItem(item: any): void {
    this.editMode = true;
    this.selectedItem = item;
    this.itemForm.patchValue(item);
  }

  deleteItem(itemId: number): void {
    this.itemService.deleteItem(itemId)
      .subscribe(
        response => {
          console.log('Item deleted successfully!', response);
          this.loadItems();
        },
        error => {
          console.error('Error deleting item:', error);
        }
      );
  }

  nameTakenValidator(control: AbstractControl): ValidationErrors | null {
    const name = control.value;
    if (this.items.some(item => item.name === name)) {
      return { nameTaken: true };
    }
    return null;
  }

  onSubmit(): void {
    if (this.itemForm.valid) {
      const newItem = this.itemForm.value;
      newItem.categoryId = newItem.category.id;

      this.itemService.addItem(newItem)
        .pipe(
          catchError((error) => {
            this.errorMessage = error;
            return throwError(error);
          })
        )
        .subscribe(
          response => {
            console.log('Item added successfully!', response);
            this.loadItems();
            this.itemForm.reset();
          },
          error => {
            console.error('Error adding item:', error);
          }
        );
    } else {
      this.markFormGroupTouched(this.itemForm);
    }
  }

  markFormGroupTouched(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      } else if (control instanceof FormArray) {
        control.controls.forEach((ctrl: AbstractControl) => this.markFormGroupTouched(ctrl as FormGroup));
      }
    });
  }

  // onSubmit(): void {
  //   if (this.itemForm.valid) {
  //     const newItem = this.itemForm.value;
  //     console.log('New Item:', newItem); // Dodajemy log, aby sprawdzić, czy wszystkie pola formularza są prawidłowo ustawione
  //     newItem.categoryId = newItem.category.id; // Ustawiamy pole categoryId na id wybranej kategorii
  //     console.log('New Item with CategoryId:', newItem); // Dodajemy log, aby sprawdzić, czy categoryId jest prawidłowo ustawione
  //     this.itemService.addItem(newItem)
  //       .pipe(
  //         catchError((error) => {
  //           this.errorMessage = error;
  //           return throwError(error);
  //         })
  //       )
  //       .subscribe(
  //         response => {
  //           console.log('Item added successfully!', response);
  //           this.loadItems();
  //           this.itemForm.reset();
  //         },
  //         error => {
  //           console.error('Error adding item:', error);
  //         }
  //       );
  //   }
  // }
}
