import {Component, OnInit} from '@angular/core';
import {UserService} from "../services/user.service";
import {MatDialog} from "@angular/material/dialog";
import {AuthService} from "../services/auth.service";
import {EditUserDataComponent} from "../edit-user-data/edit-user-data.component";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";

@Component({
  selector: 'app-user-panel',
  templateUrl: './user-panel.component.html',
  styleUrl: './user-panel.component.css'
})
export class UserPanelComponent implements OnInit{
  userData: any;
  hidePassword: boolean = true;
  userDataForm!: FormGroup;
  addressForm!: FormGroup;
  userAddresses: any[] = [];


  constructor(private userService: UserService, private dialog: MatDialog, private authService: AuthService, private formBuilder: FormBuilder) {
  }
  ngOnInit(): void {
    this.initUserDataForm();
    this.initAddressForm();
    this.loadUserData();
    this.loadUserAddresses();
  }

  initUserDataForm(): void {
    this.userDataForm = this.formBuilder.group({
      firstName: [''],
      lastName: [''],
      phoneNumber: [''],
      email: [''],
      password: ['']
    });
  }

  initAddressForm(): void {
    this.addressForm = this.formBuilder.group({
      street: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      streetNumber: ['', [Validators.required, Validators.pattern('^[0-9]+(\/[0-9]+)?$')]],
      city: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      postalCode: ['', [Validators.required, Validators.pattern('^[0-9]{2}-[0-9]{3}$')]],
      isDefault: [false]
    });
  }

  loadUserData() {
    this.userService.getUserData().subscribe(
      (data) => {
        this.userData = data;
      },
      (error) => {
        if (error.error instanceof ErrorEvent) {
          // Błąd związany z siecią lub klientem
          console.error('Wystąpił błąd podczas pobierania danych użytkownika:', error.error.message);
        } else {
          // Błąd zwrócony przez serwer
          console.error('Wystąpił błąd podczas pobierania danych użytkownika:', error.error);
        }
      }
    );
  }

  loadUserAddresses() {
    this.userService.getUserAddresses().subscribe(
      (addresses) => {
        this.userAddresses = addresses;
      },
      (error) => {
        console.error('Wystąpił błąd podczas pobierania adresów użytkownika:', error);
      }
    );
  }

  onCreate() {
    const dialogRef = this.dialog.open(EditUserDataComponent, {
      width: '400px',
      data: this.userData
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // Tutaj możesz zaktualizować dane użytkownika na podstawie formularza
      }
    });
  }

  togglePasswordVisibility(): void {
    this.hidePassword = !this.hidePassword;
  }

  logout(): void {
    this.authService.logout();
  }

  onSubmit(): void {
    if (this.userDataForm.valid) {
      const updatedUserData = this.userDataForm.value;
      this.userService.updateUserProfile(updatedUserData).subscribe(
        () => {
          console.log('Dane użytkownika zaktualizowane pomyślnie!');
          // Dodaj obsługę, np. wyświetlenie komunikatu o sukcesie
        },
        (error) => {
          console.error('Wystąpił błąd podczas aktualizacji danych użytkownika:', error);
          // Dodaj obsługę błędów, np. wyświetlenie komunikatu o błędzie
        }
      );
    }
  }

  onAddressSubmit(): void {
    if (this.addressForm.valid) {
      const newAddress = this.addressForm.value;
      this.userService.addUserAddress(newAddress).subscribe(
        () => {
          console.log('Adres dodany pomyślnie!');
          this.loadUserAddresses();
          this.addressForm.reset();
        },
        (error) => {
          console.error('Wystąpił błąd podczas dodawania adresu:', error);
        }
      );
    }
  }

  setDefaultAddress(address: any): void {
    this.userService.setDefaultUserAddress(address.id).subscribe(
      () => {
        console.log('Adres ustawiony jako domyślny!');
        this.loadUserAddresses();
      },
      (error) => {
        console.error('Wystąpił błąd podczas ustawiania domyślnego adresu:', error);
      }
    );
  }

  deleteAddress(addressId: number): void {
    this.userService.deleteUserAddress(addressId).subscribe(
      () => {
        console.log('Adres usunięty pomyślnie!');
        this.loadUserAddresses();
      },
      (error) => {
        console.error('Wystąpił błąd podczas usuwania adresu:', error);
      }
    );
  }
}


