import { Component } from '@angular/core';
import {AuthService} from "../services/auth.service";
import {Route, Router} from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email: string = '';
  password: string = '';

  constructor(private authService: AuthService, private router: Router) { }

  onSubmit() {
    this.authService.login({ email: this.email, password: this.password })
      .subscribe(response => {
        console.log('Odpowiedź z serwera:', response);
        // Przechwytywanie tokena uwierzytelniającego
        const authToken = response.token;
        // Zapisanie tokena w pamięci lokalnej przeglądarki
        localStorage.setItem('authToken', authToken);
        // Tutaj możesz obsłużyć odpowiedź z serwera, np. przekierowanie do innej strony po pomyślnym zalogowaniu
        this.router.navigate(['/user-panel']); // Tutaj 'userdetails' to ścieżka do komponentu UserDetailsComponent
      }, error => {
        console.error('Błąd logowania:', error);
        // Tutaj możesz obsłużyć błędy logowania, np. wyświetlić komunikat dla użytkownika
      });
  }

  redirectToRegistration() {
    this.router.navigate(['/registration']); // Zakładając, że '/registration' to ścieżka do strony rejestracji
  }
}
