import {Component, Input} from '@angular/core';
import {UserProfileRegistration} from "./model/user-profile-registration";

@Component({
  selector: 'app-profile-registration',
  template: `
        <pre>

          First name:        {{profileRegistration?.firstName}}
          Last name:         {{profileRegistration?.lastName}}
          Login:             {{profileRegistration?.login}}
          Email:             {{profileRegistration?.email}}
          PhoneNumber:       {{profileRegistration?.phoneNumber}}
          Password:          {{profileRegistration?.password}}
          RepeatedPassword:  {{profileRegistration?.repeatedPassword}}

        </pre>
    `,
})


export class ProfileRegistrationComponent {
  @Input()
  profileRegistration?: UserProfileRegistration
}
