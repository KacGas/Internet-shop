import {Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.css'
})
export class NavBarComponent implements OnInit{
  isLoggedIn: boolean = false;
  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  onMyAccountClick() {
    const authToken = localStorage.getItem('authToken');
    if (authToken) {
      // Użytkownik jest zalogowany, więc przekieruj go do panelu użytkownika
      this.router.navigate(['/user-panel']);
    } else {
      // Użytkownik nie jest zalogowany, przekieruj go do strony logowania
      this.router.navigate(['/login']);
    }
  }
}
