import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserService } from './services/user.service';
import { ProfileComponent } from './profile.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { FooterComponent } from './footer/footer.component';
import { RegistrationComponent } from './registration/registration.component';
import { ProfileRegistrationComponent } from './profile-registration.component';
import {UserRegistrationService} from "./services/user-registration.service";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { MainComponent } from './main/main.component';
import {CommonModule} from "@angular/common";
import { LoginComponent } from './login/login.component';
import {JwtInterceptor} from "./jwt.interceptor";
import {AuthService} from "./services/auth.service";
import { UserPanelComponent } from './user-panel/user-panel.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import {MatDialogModule} from '@angular/material/dialog';
import { EditUserDataComponent } from './edit-user-data/edit-user-data.component';
import { AddItemComponent } from './add-item/add-item.component';
import { AddComponentComponent } from './add-component/add-component.component';
import { CategoryProductComponent } from './category-product/category-product.component';
import { CartComponent } from './cart/cart.component';
import { OrderComponent } from './order/order.component';
import { HomeComponent } from './home/home.component';


@NgModule({
  bootstrap: [
    AppComponent,
  ],
  declarations: [
    AppComponent,
    ProfileComponent,
    NavBarComponent,
    FooterComponent,
    RegistrationComponent,
    ProfileRegistrationComponent,
    MainComponent,
    LoginComponent,
    UserPanelComponent,
    EditUserDataComponent,
    AddItemComponent,
    AddComponentComponent,
    CategoryProductComponent,
    CartComponent,
    OrderComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule
  ],
  providers: [
    UserService,
    UserRegistrationService,
    CommonModule,
    {provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true},
    AuthService,
    provideAnimationsAsync('noop')
  ]
})
export class AppModule { }
