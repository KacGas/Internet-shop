import {Component, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import { ItemService } from '../services/item.service';
import { CategoryService } from '../services/category.service';
import { Category } from '../model/category';
import { Item } from '../model/item';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-category-product',
  templateUrl: './category-product.component.html',
  styleUrls: ['./category-product.component.css']
})
export class CategoryProductComponent implements OnInit, OnChanges  {

  categories: Category[] = [];
  items: Item[] = [];
  selectedCategoryId: number | null = null;
  errorMessage: string = '';
  currentPage: number = 1;
  itemsPerPage: number = 10;

  constructor(private itemService: ItemService, private categoryService: CategoryService, private cartService: CartService) {}


  ngOnChanges(changes: SimpleChanges): void {
    // Jeśli zmieniła się wartość selectedCategoryId, załaduj ponownie przedmioty
    if (changes['selectedCategoryId']) {
      this.loadItems();
    }
  }
  ngOnInit(): void {
    this.loadCategories();
    this.loadItems();
  }

  loadCategories(): void {
    this.categoryService.getCategory()
      .subscribe(
        categories => {
          this.categories = categories;
        },
        error => {
          console.error('Error loading categories:', error);
        }
      );
  }

  loadItems(): void {
    this.itemService.getItems()
      .subscribe(
        items => {
          console.log('Loaded items:', items); // Sprawdź, czy poprawnie pobiera elementy
          this.items = items;
        },
        error => {
          console.error('Error loading items:', error);
        }
      );
  }


  selectCategory(categoryId: number): void {
    console.log('Selected category ID:', categoryId); // sprawdź, czy poprawnie rejestruje wybraną kategorię
    this.selectedCategoryId = categoryId;
  }


  getItemsByCategory(): Item[] {
    console.log('Selected category ID:', this.selectedCategoryId);
    console.log('All items:', this.items);

    if (this.selectedCategoryId !== null) {
      const filteredItems = this.items.filter(item => item.categoryId === this.selectedCategoryId);
      console.log('Filtered items:', filteredItems);
      return filteredItems;
    } else {
      return this.items;
    }
  }

  getCurrentPageItems(): Item[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.getItemsByCategory().slice(startIndex, endIndex);
  }

  nextPage(): void {
    const totalPages = Math.ceil(this.getItemsByCategory().length / this.itemsPerPage);
    if (this.currentPage < totalPages) {
      this.currentPage++;
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  // addToCart(itemName: string): void {
  //   this.cartService.addToCart(itemName).subscribe(
  //     response => {
  //       console.log('Item added to cart:', response);
  //     },
  //     error => {
  //       console.error('Error adding item to cart:', error);
  //     }
  //   );
  // }

  protected readonly String = String;
}
