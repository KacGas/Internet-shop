// cart.component.ts

import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {CartService} from "../services/cart.service";

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: any;

  constructor(private http: HttpClient, private cartService: CartService) { }

  ngOnInit(): void {
    this.fetchCart();
  }

  fetchCart() {
    this.cartService.getItems().subscribe(
      cart => {
        this.cart = cart;
      },
      error => {
        console.error('There was an error fetching the cart!', error);
      }
    );
  }

  removeFromCart(cartItemId: number) {
    this.http.delete(`http://localhost:8080/api/cart/remove/${cartItemId}`).subscribe(
      () => {
        this.fetchCart();
      },
      error => {
        console.error('There was an error removing from the cart!', error);
      }
    );
  }

  getTotalItems(): number {
    if (!this.cart || !this.cart.items) return 0;
    return this.cart.items.reduce((total: number, item: any) => total + item.quantity, 0);
  }

  getTotalPrice(): number {
    if (!this.cart || !this.cart.items) return 0;
    return this.cart.items.reduce((total: number, item: any) => total + (item.quantity * item.product.price), 0);
  }

  updateQuantity(itemId: number, newQuantity: number): void {
    const itemToUpdate = this.cart.items.find((item: any) => item.id === itemId);
    if (itemToUpdate) {
      itemToUpdate.quantity = newQuantity;
    }
  }

  checkout(): void {
    // Implement checkout logic here
  }
}
