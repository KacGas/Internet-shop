import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {RegistrationComponent} from "./registration/registration.component";
import {MainComponent} from "./main/main.component";
import { LoginComponent } from './login/login.component';
import {UserPanelComponent} from "./user-panel/user-panel.component";
import {AddItemComponent} from "./add-item/add-item.component";
import {AddComponentComponent} from "./add-component/add-component.component";
import { CategoryProductComponent } from './category-product/category-product.component';
import {CartComponent} from "./cart/cart.component";
import {OrderComponent} from "./order/order.component";
import {HomeComponent} from "./home/home.component";

const routes: Routes = [
  {path: '', component: HomeComponent }, // Główna strona
  {path: 'registration', component: RegistrationComponent},
  {path: 'main', component: MainComponent},
  {path: 'login', component: LoginComponent },
  {path: 'user-panel', component: UserPanelComponent},
  {path: 'add-item', component: AddItemComponent},
  {path: 'add-category', component: AddComponentComponent},
  {path: 'products', component: CategoryProductComponent},
  {path: 'cart', component: CartComponent},
  {path: 'order', component: OrderComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule,]
})
export class AppRoutingModule { }
