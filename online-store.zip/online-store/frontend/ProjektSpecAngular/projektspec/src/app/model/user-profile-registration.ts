export interface UserProfileRegistration{
  firstName: string;
  lastName: string;
  login: string;
  email: string;
  phoneNumber: string;
  password: string;
  repeatedPassword: string;
}
