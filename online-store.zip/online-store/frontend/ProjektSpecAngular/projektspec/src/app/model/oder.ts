export interface Order {
  id: number;
  orderDate: Date;
  orderStatus: OrderStatus;
  paymentMethod: PaymentMethod;
  deliveryMethod: DeliveryMethod;
  cartItem: CartItem;
}

export interface OrderStatus {
  id: number;
  name: string;
  // Add other properties as needed
}

export interface PaymentMethod {
  id: number;
  name: string;
  // Add other properties as needed
}

export interface DeliveryMethod {
  id: number;
  name: string;
  // Add other properties as needed
}

export interface CartItem {
  id: number;
  name: string;
  // Add other properties as needed
}
