export interface UserProfileLogin{
  firstName: string;
  lastName: string;
  login: string;
  email: string;
  phoneNumber: string;
  password: string;
}
