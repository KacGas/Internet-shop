export interface UserProfile {
    firstName: string;
    lastName: string;
    dateOfBirth: Date;
}