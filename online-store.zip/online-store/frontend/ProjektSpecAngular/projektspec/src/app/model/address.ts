export interface Address {
  id?: number;
  street: string;
  streetNumber: string;
  city: string;
  postalCode: string;
  isDefault: boolean;
}
