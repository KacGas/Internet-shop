import { Component, OnInit } from '@angular/core';
import { UserProfile } from './model/user-profile';
import { UserService } from './services/user.service';
import {UserProfileRegistration} from "./model/user-profile-registration";
import {UserRegistrationService} from "./services/user-registration.service";
import { ActivatedRoute, Router, NavigationEnd, Event } from '@angular/router';
import {filter} from "rxjs";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'User profile';

  userProfile?: UserProfile;

  userProfileRegistration?: UserProfileRegistration;

  showOnHomePage: boolean = false;

  constructor(private userService: UserService, private userRegistrationService: UserRegistrationService, private router: Router) {
    userService.getUserProfile().subscribe(userProfile => this.userProfile = userProfile);
    userRegistrationService.getUserProfileRegistration().subscribe(userProfileRegistration => this.userProfileRegistration = userProfileRegistration);
  }

  ngOnInit() {
    this.router.events.pipe(
      filter((event: Event): event is NavigationEnd => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.showOnHomePage = (event.url === '/');
    });
  }

}
